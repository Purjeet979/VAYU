import urllib.request
import json

url = 'http://localhost:8000/api/cpcb/latest'
response = urllib.request.urlopen(url).read()
data = json.loads(response)

valid = [s for s in data if s.get('aqi') is not None]
if valid:
    max_station = max(valid, key=lambda x: x['aqi'])
    print(f"Max AQI: {max_station['aqi']} at {max_station['station_name']} in {max_station['city']}")
    print(f"District: {max_station['city']}")
else:
    print("No valid AQI data found.")
