import json
import urllib.request
import math
from shapely.geometry import shape, Point, Polygon, MultiPolygon

def get_cpcb_color_bin(val):
    if val is None or math.isnan(val): return -1
    if val > 250: return 5
    if val > 120: return 4
    if val > 90: return 3
    if val > 60: return 2
    if val > 30: return 1
    return 0

def run_verification():
    # Load districts
    with open('frontend/public/ncr_districts.geojson', 'r') as f:
        geo = json.load(f)
    
    # Load live grid data from backend
    req = urllib.request.urlopen('http://localhost:8000/api/map-data?hour=24&variable=pm25')
    grid_res = json.loads(req.read().decode())
    grid = grid_res['grid']
    
    lats = grid['lat']
    lons = grid['lon']
    values = grid['values']
    
    # Calculate cell sizes (dx, dy)
    dx = lons[1] - lons[0]
    dy = lats[1] - lats[0]
    
    mismatches = []
    max_error = 0
    
    for feature in geo['features']:
        name = feature['properties']['name']
        poly = shape(feature['geometry'])
        
        # Method 1: Binary Centroid (what frontend does)
        binary_sum = 0
        binary_count = 0
        
        # Method 2: Area Weighted
        area_sum = 0
        total_area = 0
        
        # Bounding box for optimization
        min_lon, min_lat, max_lon, max_lat = poly.bounds
        
        for i in range(len(lats)):
            lat = lats[i]
            if lat + dy/2 < min_lat or lat - dy/2 > max_lat: continue
                
            for j in range(len(lons)):
                lon = lons[j]
                if lon + dx/2 < min_lon or lon - dx/2 > max_lon: continue
                    
                val = values[i][j]
                if val is None: continue
                
                pt = Point(lon, lat)
                if poly.contains(pt):
                    binary_sum += val
                    binary_count += 1
                
                # Area calculation
                cell_poly = Polygon([
                    (lon - dx/2, lat - dy/2),
                    (lon + dx/2, lat - dy/2),
                    (lon + dx/2, lat + dy/2),
                    (lon - dx/2, lat + dy/2)
                ])
                
                if poly.intersects(cell_poly):
                    intersection_area = poly.intersection(cell_poly).area
                    if intersection_area > 0:
                        area_sum += val * intersection_area
                        total_area += intersection_area
        
        val_binary = (binary_sum / binary_count) if binary_count > 0 else None
        val_area = (area_sum / total_area) if total_area > 0 else None
        
        if val_binary is None or val_area is None:
            continue
            
        error_pct = abs(val_binary - val_area) / val_area * 100
        max_error = max(max_error, error_pct)
        
        bin_binary = get_cpcb_color_bin(val_binary)
        bin_area = get_cpcb_color_bin(val_area)
        
        if bin_binary != bin_area:
            mismatches.append(f"{name}: Binary={val_binary:.1f} (Bin {bin_binary}), Area={val_area:.1f} (Bin {bin_area})")
            
    print(f"Max Error: {max_error:.2f}%")
    if mismatches:
        print("MISMATCHES FOUND:")
        for m in mismatches: print(m)
    else:
        print("SUCCESS: 0 mismatches in color bins. The binary centroid assumption holds true for the current grid.")

if __name__ == '__main__':
    run_verification()
