import pandas as pd
from pathlib import Path

live_dir = Path(__file__).resolve().parent.parent / "data" / "live"
cpcb_file = live_dir / "cpcb_live.csv"

if not cpcb_file.exists():
    print(f"File not found: {cpcb_file}")
    exit(1)

df = pd.read_csv(cpcb_file)
total_stations = len(df)
print(f"Total stations: {total_stations}")

# Print columns to see how pollutants are named
print("Columns:", df.columns.tolist())

# Assuming columns might be named 'PM2.5', 'PM10', 'NO2', etc.
pollutants = ["PM2.5", "PM10", "NO2", "SO2", "CO", "OZONE", "O3"]
valid_counts = {}

for p in pollutants:
    # Handle possible case variations
    matches = [c for c in df.columns if c.upper() == p.upper()]
    if matches:
        col = matches[0]
        # Count non-null and non-'NA' values
        df[col] = pd.to_numeric(df[col], errors='coerce')
        valid_counts[col] = df[col].notna().sum()
    else:
        valid_counts[p] = 0

print("\nValid non-null values per pollutant in CPCB live data (CSV):")
for p, count in valid_counts.items():
    pct = (count / total_stations) * 100 if total_stations > 0 else 0
    print(f"{p:<6}: {count:>3} / {total_stations} ({pct:.1f}%)")
