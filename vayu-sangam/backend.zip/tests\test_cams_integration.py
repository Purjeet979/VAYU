import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch
from app.main import app

client = TestClient(app)

def test_cams_comparison_insufficient_data():
    """
    Test Phase 4 CAMS Integration when there is insufficient historical data.
    The endpoint must honestly flag 'not_yet_available' for bias_correction.
    """
    
    # We mock cached_forecast to simulate an empty live cache scenario (bundled_demo_dataset fallback)
    with patch("app.main.cached_forecast") as mock_forecast:
        mock_forecast.return_value = {
            "mode": "demo",
            "data_source": "bundled_demo_dataset",
            "forecast": [{"pm25_ug_m3": 45.0}]
        }
        
        response = client.get("/api/cams-comparison?district=Delhi&hour=0")
        assert response.status_code == 200
        
        data = response.json()
        
        # 1. XGBoost forecast MUST explicitly fall back to null/unavailable if cache is empty
        assert data["xgboost_local_forecast"] is None
        assert "unavailable" in data["xgboost_status"].lower()
        
        # 2. Honest flag for bias correction must be set
        assert data["bias_correction"] == "not_yet_available"
        assert "accumulating historical data" in data["reason"].lower()

def test_cams_comparison_with_data():
    """
    Test CAMS Integration when live data is available.
    """
    with patch("app.main.cached_forecast") as mock_forecast:
        mock_forecast.return_value = {
            "mode": "live",
            "data_source": "live_fetch",
            "forecast": [{"pm25_ug_m3": 45.0}]
        }
        
        response = client.get("/api/cams-comparison?district=Delhi&hour=0")
        assert response.status_code == 200
        
        data = response.json()
        
        # Local forecast should be valid
        assert data["xgboost_local_forecast"] == 45.0
        assert data["xgboost_status"] == "Available"
        
        # CAMS value should be returned (from the real JSON file or 0.0 if mocked/missing)
        assert "cams_downscaled" in data
        assert isinstance(data["agreement_pct"], (int, float))
