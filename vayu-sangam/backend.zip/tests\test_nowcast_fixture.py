import numpy as np
import pandas as pd
import pytest

import sys
import os

# Add scripts directory to path to import generate_nowcast_grid
scripts_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "scripts")
sys.path.append(scripts_dir)

from generate_nowcast_grid import idw_interpolate

def test_idw_fixture_exact_math():
    """
    Test IDW interpolation with hand-calculated expected values.
    
    Stations:
    S1: (28.0, 77.0) -> val: 100
    S2: (28.0, 78.0) -> val: 200
    S3: (29.0, 77.0) -> val: 300
    
    We need 5 stations to pass the MIN_STATIONS_REQUIRED check, 
    so we'll add 2 more dummy stations far away that won't affect the exact math much, 
    or we can just mock MIN_STATIONS_REQUIRED for this test.
    Let's mock MIN_STATIONS_REQUIRED.
    """
    import generate_nowcast_grid
    generate_nowcast_grid.MIN_STATIONS_REQUIRED = 3
    
    stations = pd.DataFrame([
        {"lat": 28.0, "lon": 77.0, "pollutant": "pm25", "value": 100.0},
        {"lat": 28.0, "lon": 78.0, "pollutant": "pm25", "value": 200.0},
        {"lat": 29.0, "lon": 77.0, "pollutant": "pm25", "value": 300.0},
    ])
    
    grid_lats = np.array([28.5, 28.0])
    grid_lons = np.array([77.5, 77.5])
    
    # Hand calculation for (28.5, 77.5):
    # d2(S1) = 0.5, d2(S2) = 0.5, d2(S3) = 0.5
    # w = 1/d2 -> w1=2, w2=2, w3=2
    # val = (2*100 + 2*200 + 2*300) / 6 = 1200 / 6 = 200.0
    
    # Hand calculation for (28.0, 77.5):
    # d2(S1) = 0.25, d2(S2) = 0.25, d2(S3) = 1.25
    # w1=4, w2=4, w3=0.8
    # val = (4*100 + 4*200 + 0.8*300) / 8.8 = 1440 / 8.8 = 163.63636363636363
    
    grid = idw_interpolate(stations, "pm25", grid_lats, grid_lons, power=2.0)
    
    # Since our test evaluates 2 specific points instead of a matrix, we just check the diagonal
    # grid[0, 0] corresponds to grid_lats[0] and grid_lons[0] -> (28.5, 77.5)
    # grid[1, 1] corresponds to grid_lats[1] and grid_lons[1] -> (28.0, 77.5)
    
    val_point1 = grid[0, 0]
    val_point2 = grid[1, 1]
    
    assert np.isclose(val_point1, 200.0), f"Expected 200.0, got {val_point1}"
    assert np.isclose(val_point2, 163.63636363636363), f"Expected 163.636, got {val_point2}"
    
    print("IDW Fixture Test Passed!")
    
if __name__ == "__main__":
    test_idw_fixture_exact_math()
