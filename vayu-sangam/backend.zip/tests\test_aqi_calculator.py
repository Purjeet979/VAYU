import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
import pytest
from app.aqi_calculator import calculate_sub_index, calculate_overall_aqi

@pytest.mark.parametrize("pollutant,conc,expected", [
    # PM2.5 tests
    ("pm25", 15, 25),     # Good (0-30 => 0-50) => (50/30)*15 = 25
    ("pm25", 45, 75),     # Satisfactory (31-60 => 51-100) => (49/29)*(45-31)+51 = 75
    ("pm25", 75, 149),    # Moderate (61-90 => 101-200) => (99/29)*(75-61)+101 = 149
    ("pm25", 100, 232),   # Poor (91-120 => 201-300) => (99/29)*(100-91)+201 = 232
    
    # PM10 boundary tests
    ("pm10", 250, 200),   # Boundary Moderate End
    ("pm10", 251, 201),   # Boundary Poor Start
    ("pm10", 350, 300),   # Boundary Poor End
    ("pm10", 351, 301),   # Boundary Very Poor Start
    
    # NO2 boundary tests
    ("no2", 180, 200),    # Boundary Moderate End
    ("no2", 181, 201),    # Boundary Poor Start
    
    # O3 boundary tests
    ("o3", 168, 200),     # Boundary Moderate End
    ("o3", 169, 201),     # Boundary Poor Start
    
    # CO boundary tests
    ("co", 10.0, 200),    # Boundary Moderate End
    ("co", 10.1, 201),    # Boundary Poor Start
])
def test_sub_index_calculation(pollutant, conc, expected):
    res = calculate_sub_index(pollutant, conc)
    assert res == expected, f"Expected {expected} for {pollutant}={conc}, got {res}"

def test_overall_aqi_calculation():
    # Should pick max
    res, prom = calculate_overall_aqi({"pm25": 75, "pm10": 175, "no2": 20})
    # PM2.5(75) => 149
    # PM10(175) => 150
    # NO2(20) => 25
    assert res == 150
    assert prom == "pm10"
