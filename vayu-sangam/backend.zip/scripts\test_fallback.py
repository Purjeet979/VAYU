import sqlite3
import requests
import time

DB_PATH = "/home/ubuntu/backend/data/live/cpcb_history.db"

def check_apis(label=""):
    print(f"\n--- API STATUS ({label}) ---")
    
    # 1. FORECAST
    f = requests.get('http://54.226.71.16:8000/api/forecast').json()
    print(f"1. FORECAST -> data_source: {f.get('data_source')}")
    print(f"   Status: {f.get('scientific_status')}")
    
    # 2. INVERSION
    i = requests.get('http://54.226.71.16:8000/api/inversion').json()
    print(f"2. INVERSION -> data_source: {i.get('data_source')}, Pblh: {i.get('pbl_height_m')}, Wind: {i.get('wind_speed_mps')}")
    
    # 3. SHAP
    d = requests.get('http://54.226.71.16:8000/api/dashboard-summary').json()
    shap_status = d.get('explanation', {}).get('scientific_status')
    print(f"3. SHAP -> status: {shap_status}")


if __name__ == "__main__":
    print("Testing LIVE state...")
    check_apis("LIVE (24/24 HOURS)")
    
    # Break the buffer artificially by deleting older data
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        
        # Calculate 12 hours ago
        import datetime
        t = datetime.datetime.utcnow() + datetime.timedelta(hours=5, minutes=30) - datetime.timedelta(hours=12)
        cutoff = t.strftime('%Y-%m-%dT%H')
        
        cursor.execute("SELECT * FROM readings WHERE timestamp <= ?", (cutoff,))
        rows = cursor.fetchall()
        
        print(f"\n[!] Artificially breaking buffer... Deleting {len(rows)} rows before {cutoff}...")
        cursor.execute("DELETE FROM readings WHERE timestamp <= ?", (cutoff,))
        conn.commit()
        
    print("[!] Triggering background cache generation to reflect DB changes...")
    import os
    os.system("sudo systemctl start vayu-ml-forecast.service")
    time.sleep(2)
    check_apis("BROKEN BUFFER (<24 HOURS)")
    
    # Restore the buffer
    print(f"\n[!] Restoring buffer... Re-inserting {len(rows)} rows...")
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.executemany("INSERT INTO readings VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", rows)
        conn.commit()
        
    print("[!] Triggering background cache generation to reflect DB changes...")
    os.system("sudo systemctl start vayu-ml-forecast.service")
    time.sleep(2)
    check_apis("RESTORED LIVE (24/24 HOURS)")

