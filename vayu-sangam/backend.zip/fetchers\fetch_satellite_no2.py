import os
import json
import time
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import xarray as xr
from dotenv import load_dotenv

try:
    import ee
except ImportError:
    ee = None

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
LIVE_DIR = DATA_DIR / "live"
CACHE_DIR = DATA_DIR / "cache"

LIVE_FILE = LIVE_DIR / "no2_satellite_live.nc"
CACHE_FILE = CACHE_DIR / "no2_satellite_cache.nc"
META_FILE = LIVE_DIR / "fetch_satellite_no2.meta.json"

def ensure_dir(d: Path):
    d.mkdir(parents=True, exist_ok=True)

def init_ee():
    if not ee:
        raise ImportError("The 'earthengine-api' package is not installed.")
    
    key_path = os.getenv("GEE_SERVICE_ACCOUNT_KEY_PATH")
    if not key_path or not os.path.exists(key_path):
        raise ValueError(f"GEE service account JSON not found at path: '{key_path}'. Check GEE_SERVICE_ACCOUNT_KEY_PATH in .env")
    
    with open(key_path, 'r') as f:
        credentials_dict = json.load(f)
        
    creds = ee.ServiceAccountCredentials(credentials_dict['client_email'], key_path)
    ee.Initialize(creds)

def get_grid_points():
    """Returns exactly the 24x26 mesh grid points mapped as an ee.FeatureCollection"""
    lat_vals = np.linspace(27, 31, 24)
    lon_vals = np.linspace(73, 80, 26)
    
    features = []
    for lat in lat_vals:
        for lon in lon_vals:
            geom = ee.Geometry.Point([float(lon), float(lat)])
            feat = ee.Feature(geom, {'lat': float(lat), 'lon': float(lon)})
            features.append(feat)
            
    fc = ee.FeatureCollection(features)
    return lat_vals, lon_vals, fc

def fetch_no2_live():
    """
    Fetches S5P NO2 (tropospheric_NO2_column_number_density) over the last 3 days,
    samples it onto the 24x26 grid, and saves it to a NetCDF file.
    """
    logger.info("Triggering live NO2 fetch...")
    init_ee()
    
    lat_vals, lon_vals, fc = get_grid_points()
    
    end_date = datetime.now(timezone.utc)
    start_date = end_date - timedelta(days=3)
    
    logger.info(f"Fetching S5P NO2 from {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}")
    
    def mask_no2(image):
        cloud_fraction = image.select('cloud_fraction')
        return image.updateMask(cloud_fraction.lt(0.3))

    collection = ee.ImageCollection("COPERNICUS/S5P/NRTI/L3_NO2") \
                   .filterDate(start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d')) \
                   .map(mask_no2) \
                   .select('tropospheric_NO2_column_number_density')
                   
    max_retries = 3
    data = None
    
    for i in range(max_retries):
        try:
            if collection.size().getInfo() == 0:
                logger.error("No NO2 images available in GEE for the last 3 days.")
                return
                
            latest_img = collection.median()
            logger.info(f"Sampling latest 3-day median NO2 image (Attempt {i+1})...")
            
            sampled = latest_img.reduceRegions(
                collection=fc,
                reducer=ee.Reducer.first(),
                scale=11132
            )
            data = sampled.getInfo()
            break
        except Exception as e:
            logger.warning(f"GEE API fetch failed (Attempt {i+1}/{max_retries}): {e}")
            if i < max_retries - 1:
                time.sleep(2 ** i)
                
    if not data:
        logger.error("Live fetch exhausted all retries. Check GEE quotas/connectivity.")
        return
        
    live_flat = np.full((len(lat_vals), len(lon_vals)), np.nan)
    for feat in data.get('features', []):
        props = feat.get('properties', {})
        lat = props.get('lat')
        lon = props.get('lon')
        val = props.get('first')
        
        if val is not None and lat is not None and lon is not None:
            lat_idx = (np.abs(lat_vals - lat)).argmin()
            lon_idx = (np.abs(lon_vals - lon)).argmin()
            live_flat[lat_idx, lon_idx] = val
            
    # Spatially fill any missing pixels in the live scan
    df = pd.DataFrame(live_flat)
    df = df.ffill(axis=0).bfill(axis=0).ffill(axis=1).bfill(axis=1)
    live_flat = df.values
    
    ds = xr.Dataset(
        data_vars={
            "no2_column_density": (["lat", "lon"], live_flat),
        },
        coords={
            "lat": lat_vals,
            "lon": lon_vals
        }
    )
    
    fetch_time_utc = datetime.now(timezone.utc).isoformat()
    ds.attrs['fetch_time_utc'] = fetch_time_utc
    ds.attrs['source'] = 'COPERNICUS/S5P/NRTI/L3_NO2 - tropospheric_NO2_column_number_density'
    
    ensure_dir(LIVE_DIR)
    ensure_dir(CACHE_DIR)
    
    tmp_live = LIVE_DIR / ".no2_satellite_live.nc.tmp"
    ds.to_netcdf(tmp_live)
    os.replace(tmp_live, LIVE_FILE)
    
    tmp_cache = CACHE_DIR / ".no2_satellite_cache.nc.tmp"
    ds.to_netcdf(tmp_cache)
    os.replace(tmp_cache, CACHE_FILE)
    
    meta = {
        "last_successful_fetch_utc": fetch_time_utc,
        "grid_points": len(lat_vals) * len(lon_vals),
        "source": "COPERNICUS/S5P/NRTI/L3_NO2",
        "band": "tropospheric_NO2_column_number_density"
    }
    with open(META_FILE, "w") as f:
        json.dump(meta, f)
        
    logger.info(f"Success! NO2 grid saved to {LIVE_FILE}")

def main():
    load_dotenv(BASE_DIR.parent / ".env")
    fetch_no2_live()

if __name__ == "__main__":
    main()
