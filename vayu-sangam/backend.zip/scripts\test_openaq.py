import os, requests
from dotenv import load_dotenv
load_dotenv(r"E:\SIH2\Vayusangam\vayu-sangam\.env")
print("Key:", os.getenv("OPENAQ_API_KEY"))
url = "https://api.openaq.org/v3/locations?coordinates=28.6,77.2&radius=25000&limit=1"
headers = {"X-API-Key": os.getenv("OPENAQ_API_KEY")}
r = requests.get(url, headers=headers)
data = r.json()
if len(data.get("results", [])) > 0:
    loc_id = data["results"][0]["id"]
    r2 = requests.get(f"https://api.openaq.org/v3/locations/{loc_id}/latest", headers=headers)
    print("Latest data:", r2.json())
