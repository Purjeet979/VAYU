import os
import json
import logging
import traceback
import xarray as xr
import pandas as pd
from datetime import datetime, timedelta, timezone
from pathlib import Path
from dotenv import load_dotenv
import cdsapi

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)

# Constants
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
LIVE_DIR = DATA_DIR / "live"
META_FILE = LIVE_DIR / "fetch_cams.meta.json"
CAMS_JSON_FILE = LIVE_DIR / "cams_forecast.json"

def ensure_dir(d):
    d.mkdir(parents=True, exist_ok=True)

def fetch_cams_data():
    load_dotenv(BASE_DIR.parent / ".env")
    
    ads_api_key = os.getenv("ADS_API_KEY")
    ads_url = os.getenv("ADS_URL", "https://ads.atmosphere.copernicus.eu/api")
    
    if not ads_api_key or "your_" in ads_api_key:
        logger.error("ADS_API_KEY is not set or is invalid in .env. Skipping CAMS fetch.")
        return False

    ensure_dir(LIVE_DIR)

    # We will try fetching today's 00:00 run. If it fails, we fall back to yesterday's 00:00 run.
    now = datetime.now(timezone.utc)
    dates_to_try = [
        now.strftime("%Y-%m-%d"),
        (now - timedelta(days=1)).strftime("%Y-%m-%d")
    ]
    
    # Configure cdsapi client directly with URL and KEY
    try:
        c = cdsapi.Client(url=ads_url, key=ads_api_key)
    except Exception as e:
        logger.error(f"Failed to initialize cdsapi client: {e}")
        return False

    downloaded_nc_aero = LIVE_DIR / "temp_cams_aero.nc"
    downloaded_nc_gas = LIVE_DIR / "temp_cams_gas.nc"
    success = False

    for run_date in dates_to_try:
        try:
            logger.info(f"Attempting to fetch CAMS aerosols for {run_date}...")
            c.retrieve(
                'cams-global-atmospheric-composition-forecasts',
                {
                    'date': f'{run_date}/{run_date}',
                    'type': 'forecast',
                    'format': 'netcdf',
                    'variable': ['particulate_matter_10um', 'particulate_matter_2.5um'],
                    'time': '00:00',
                    'leadtime_hour': [str(x) for x in range(0, 121, 3)],
                    'area': [29.3, 76.5, 28.0, 78.5], 
                },
                str(downloaded_nc_aero)
            )
            
            logger.info(f"Attempting to fetch CAMS gases for {run_date}...")
            c.retrieve(
                'cams-global-atmospheric-composition-forecasts',
                {
                    'date': f'{run_date}/{run_date}',
                    'type': 'forecast',
                    'format': 'netcdf',
                    'variable': ['carbon_monoxide', 'nitrogen_dioxide', 'ozone'],
                    'model_level': '137', # Surface layer
                    'time': '00:00',
                    'leadtime_hour': [str(x) for x in range(0, 121, 3)],
                    'area': [29.3, 76.5, 28.0, 78.5], 
                },
                str(downloaded_nc_gas)
            )
            success = True
            logger.info(f"Successfully downloaded CAMS data for {run_date}.")
            break
        except Exception as e:
            logger.warning(f"Failed to fetch for {run_date}. Reason: {e}")
            if "terms" in str(e).lower() or "403" in str(e):
                logger.error("Authentication/License error. Ensure you have accepted the dataset terms of use on the Copernicus ADS website.")
                break 
            
    if not success:
        logger.error("All fetch attempts for CAMS failed. Proceeding without new CAMS data (Best-effort fallback).")
        return False
        
    # Process the NetCDF files
    try:
        ds_aero = xr.open_dataset(downloaded_nc_aero)
        ds_gas = xr.open_dataset(downloaded_nc_gas)
        
        df_aero = ds_aero.to_dataframe().reset_index()
        df_gas = ds_gas.to_dataframe().reset_index()
        
        # We merge them on time, lat, lon
        # First standardize column names to avoid conflicts if they differ slightly
        time_col_aero = 'valid_time' if 'valid_time' in df_aero.columns else 'time'
        time_col_gas = 'valid_time' if 'valid_time' in df_gas.columns else 'time'
        
        df_aero.rename(columns={time_col_aero: 'forecast_time'}, inplace=True)
        df_gas.rename(columns={time_col_gas: 'forecast_time'}, inplace=True)
        
        var_map = {
            'pm2p5': 'pm25', 'pm10': 'pm10',
            'no2': 'no2', 'go3': 'o3', 'co': 'co'
        }
        for col in df_aero.columns:
            for k, v in var_map.items():
                if k == col or k in col:
                    df_aero.rename(columns={col: v}, inplace=True)
                    
        for col in df_gas.columns:
            for k, v in var_map.items():
                if k == col or k in col:
                    df_gas.rename(columns={col: v}, inplace=True)
                    
        df = pd.merge(df_aero, df_gas, on=['forecast_time', 'latitude', 'longitude'], how='outer')
        
        records = []
        for _, row in df.iterrows():
            # TODO: Phase 4: Add `cams_forecast_generated_at` staleness field for cross-validation UI
            # e.g., "cams_forecast_generated_at": now.isoformat()
            
            # CAMS native units for aerosols and gases are kg/m3. CPCB uses ug/m3. (1 kg = 1e9 ug)
            record = {
                "forecast_time_utc": row['forecast_time'].isoformat() + "Z" if hasattr(row['forecast_time'], 'isoformat') else str(row['forecast_time']),
                "lat": float(row['latitude']),
                "lon": float(row['longitude']),
                "pm25": float(row.get('pm25', 0)) * 1e9 if pd.notna(row.get('pm25')) else 0.0,
                "pm10": float(row.get('pm10', 0)) * 1e9 if pd.notna(row.get('pm10')) else 0.0,
                "no2": float(row.get('no2', 0)) * 1e9 if pd.notna(row.get('no2')) else 0.0,  
                "o3": float(row.get('o3', 0)) * 1e9 if pd.notna(row.get('o3')) else 0.0,    
                "co": float(row.get('co', 0)) * 1e9 if pd.notna(row.get('co')) else 0.0     
            }
            records.append(record)
            
        ds_aero.close()
        ds_gas.close()
        if downloaded_nc_aero.exists(): downloaded_nc_aero.unlink()
        if downloaded_nc_gas.exists(): downloaded_nc_gas.unlink()
            
        # Atomic write
        tmp_json = LIVE_DIR / ".cams_forecast.json.tmp"
        with open(tmp_json, "w") as f:
            json.dump(records, f)
        os.replace(tmp_json, CAMS_JSON_FILE)
        
        # Write metadata
        meta = {
            "last_successful_fetch_utc": datetime.now(timezone.utc).isoformat(),
            "row_count": len(records),
            "status": "success"
        }
        with open(META_FILE, "w") as f:
            json.dump(meta, f)
            
        logger.info(f"Successfully processed and saved {len(records)} CAMS forecast rows.")
        return True
        
    except Exception as e:
        logger.error(f"Error processing CAMS NetCDF: {e}")
        logger.error(traceback.format_exc())
        return False

if __name__ == "__main__":
    fetch_cams_data()
