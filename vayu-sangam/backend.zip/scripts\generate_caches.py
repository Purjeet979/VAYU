"""Runs the heavy ML inference pipeline and serializes the dashboard output to JSON."""

import sys
import os
from pathlib import Path
import json
import logging
from datetime import datetime, timezone, timedelta

# Add backend to path so we can import app modules
BASE_DIR = Path(__file__).resolve().parent.parent.parent
sys.path.append(str(BASE_DIR))

# Ensure DATA_MODE is live for cache generation
os.environ["DATA_MODE"] = "live"

from backend.app.api_service import _compute_dashboard_summary, _compute_map_data, _compute_station_forecasts

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def generate_all_caches():
    data_dir = BASE_DIR / "backend" / "data" / "cache"
    data_dir.mkdir(parents=True, exist_ok=True)
    
    now_utc = datetime.now(timezone.utc)
    now_iso = now_utc.isoformat()
    
    try:
        logger.info("Generating dashboard summary...")
        # Since we modified the API to dynamically check history, this will inherently do the buffer check!
        dashboard = _compute_dashboard_summary(hours=72, hour=24)
        
        # Calculate underlying data age
        meta_path = BASE_DIR / "backend" / "data" / "live" / "fetch_cpcb.meta.json"
        data_age_hours = 0
        if meta_path.exists():
            try:
                with open(meta_path, "r") as f:
                    meta = json.load(f)
                ts = meta.get("last_successful_fetch_utc", "")
                data_dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                data_age_hours = (now_utc - data_dt).total_seconds() / 3600
            except Exception:
                pass
                
        # Add caching metadata
        dashboard["cache_metadata"] = {
            "generated_at_utc": now_iso,
            "underlying_data_age_hours": data_age_hours,
            "buffer_status": dashboard["forecast"]["scientific_status"]
        }
        
        # Atomically write to dashboard.json
        temp_path = data_dir / "dashboard.tmp.json"
        with open(temp_path, "w") as f:
            json.dump(dashboard, f, separators=(',', ':'))
        temp_path.replace(data_dir / "dashboard.json")
        logger.info("Successfully wrote dashboard.json")
        
        # Generating map layers
        logger.info("Generating map layers...")
        for var in ["pm25", "pm10", "o3", "nox"]:
            map_data = _compute_map_data(hour=24, variable=var)
            map_data["cache_metadata"] = {"generated_at_utc": now_iso}
            m_temp = data_dir / f"map_{var}.tmp.json"
            with open(m_temp, "w") as f:
                json.dump(map_data, f, separators=(',', ':'))
            m_temp.replace(data_dir / f"map_{var}.json")
            
        logger.info("Generating station forecasts...")
        station_data = _compute_station_forecasts()
        s_temp = data_dir / "stations.tmp.json"
        with open(s_temp, "w") as f:
            json.dump({"metadata": {"generated_at_utc": now_iso}, "data": station_data}, f)
        s_temp.replace(data_dir / "stations.json")

    except Exception as e:
        logger.error(f"Failed to generate caches: {e}")
        sys.exit(1)

if __name__ == "__main__":
    generate_all_caches()
