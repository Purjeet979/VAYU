import pytest
from unittest.mock import patch
from backend.app.api_service import _compute_forecast

@patch("backend.scripts.cpcb_history_store.get_history_count")
def test_dynamic_fallback_sufficient_data(mock_get_history_count):
    """When the buffer has 24h data, the system should use XGBoost live inference."""
    # Mock the DB check
    mock_get_history_count.return_value = {
        "required_observations": 24,
        "valid_observations": 24,
        "coverage_percent": 100.0,
        "status": "sufficient"
    }
    
    # We mock _load_models to avoid loading actual heavy models during tests,
    # but the logic in get_live_forecast_data will still execute and hit the 'sufficient' path.
    with patch("backend.app.live_inference._load_models") as mock_load:
        # Mock load_models so it doesn't fail trying to load the real XGBoost
        mock_load.return_value = {"xgboost": "dummy_model"}
        with patch("backend.app.live_inference.r2_score") as mock_r2:
            mock_r2.return_value = 0.99
            with patch("backend.app.api_service.get_demo_forecast_model") as mock_demo:
                mock_demo.return_value.predict.return_value = None # Just stub it
                
                result = _compute_forecast(hours=24)
                
                assert result["data_source"] == "xgboost_live_inference"
                assert "held-out test R2=0.97" in result["scientific_status"]

@patch("backend.scripts.cpcb_history_store.get_history_count")
def test_dynamic_fallback_insufficient_data(mock_get_history_count):
    """When the buffer is broken, the system must gracefully fall back to the demo dataset."""
    # Mock the DB check returning < 24h
    mock_get_history_count.return_value = {
        "required_observations": 24,
        "valid_observations": 12,
        "coverage_percent": 50.0,
        "status": "insufficient"
    }
    
    with patch("backend.app.api_service.get_demo_forecast_model") as mock_demo:
        class DummyModel:
            def get_predictions(self, *args, **kwargs):
                return []
        mock_demo.return_value = DummyModel()
        
        result = _compute_forecast(hours=24)
        
        assert result["data_source"] == "bundled_demo_dataset"
        assert "insufficient_data: 12/24 hours collected" in result["scientific_status"]
