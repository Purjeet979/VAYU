import sys
from pathlib import Path
import unittest
from unittest.mock import patch, MagicMock
import datetime

BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.append(str(BASE_DIR))

from fetchers.sources import CPCBSource, OpenAQSource, WAQISource, LastKnownGoodSource
from fetchers.fetch_cpcb import map_stations
import pandas as pd

class TestIngestionPipeline(unittest.TestCase):
    def setUp(self):
        self.cpcb = CPCBSource("dummy_key")
        self.openaq = OpenAQSource("dummy_key")
        self.waqi = WAQISource("dummy_key")
        
        now = datetime.datetime.now(datetime.timezone.utc)
        ist_now = now + datetime.timedelta(hours=5, minutes=30)
        self.fresh_time = ist_now.strftime('%d-%m-%Y %H:%M:%S')
        self.stale_time = (now - datetime.timedelta(hours=5)).strftime('%Y-%m-%dT%H:%M:%SZ')

    @patch('requests.get')
    def test_cpcb_success_fresh(self, mock_get):
        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            'records': [
                {'last_update': self.fresh_time, 'station': 'TestStation', 'city': 'Delhi', 'latitude': '28.0', 'longitude': '77.0', 'pollutant_id': 'PM2.5', 'pollutant_avg': 45.0}
            ],
            'total': 1
        }
        mock_get.return_value = mock_resp
        
        records = self.cpcb.fetch(['Delhi'])
        self.assertEqual(len(records), 1)
        valid, metrics = self.cpcb.validate_and_filter(records)
        self.assertEqual(metrics["fresh"], 1)

    @patch('requests.get')
    def test_cpcb_timeout_triggers_fallback_simulation(self, mock_get):
        # We simulate the controller loop
        import requests
        mock_get.side_effect = requests.exceptions.Timeout("Timeout")
        
        with self.assertRaises(requests.exceptions.Timeout):
            self.cpcb.fetch(['Delhi'])

    @patch('requests.get')
    def test_openaq_stale_data_rejected(self, mock_get):
        mock_resp_loc = MagicMock()
        mock_resp_loc.json.return_value = {'results': [{'id': 1, 'name': 'TestLocation', 'city': 'Delhi', 'sensors': [{'id': 100, 'parameter': {'name': 'pm25'}}]}]}
        
        mock_resp_latest = MagicMock()
        mock_resp_latest.json.return_value = {
            'results': [{'sensorsId': 100, 'value': 45.0, 'datetime': {'utc': self.stale_time}}]
        }
        
        # side_effect to return locations then latest
        mock_get.side_effect = [mock_resp_loc, mock_resp_latest]
        
        records = self.openaq.fetch()
        valid, metrics = self.openaq.validate_and_filter(records)
        
        self.assertEqual(metrics["stale"], 1)
        self.assertEqual(metrics["fresh"], 0)
        self.assertEqual(len(valid), 0)

    def test_lkg_marks_degraded(self):
        # Create dummy temp csv
        import tempfile, os
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix=".csv") as f:
            f.write("timestamp,station_id,pm25\n")
            f.write(f"{(datetime.datetime.now(datetime.timezone.utc)).strftime('%Y-%m-%dT%H:%M:%SZ')},123,45.0\n")
            temp_path = f.name
            
        try:
            lkg = LastKnownGoodSource(temp_path)
            records = lkg.fetch()
            valid, metrics = lkg.validate_and_filter(records)
            self.assertEqual(len(valid), 1)
            self.assertEqual(valid[0]["quality"], "degraded")
            self.assertEqual(valid[0]["confidence"], "low")
        finally:
            os.remove(temp_path)

    def test_openaq_iso_date_parsing(self):
        # OpenAQ returns ISO-8601 strings. 2026-09-11 should be parsed as Sept 11, NOT Nov 9.
        # This was a previous critical bug due to dayfirst=True in older implementations.
        raw_records = [{
            "station": "Test Location", "latitude": 28.0, "longitude": 77.0,
            "pm25": 45.0, "timestamp": "2026-09-11T10:00:00Z"
        }]
        valid, metrics = self.openaq.validate_and_filter(raw_records)
        now = datetime.datetime.now(datetime.timezone.utc)
        ambiguous_date_str = now.strftime('%Y-%m-%dT%H:%M:%SZ') # e.g. 2026-09-19
        
        raw_records_2 = [{
            "station": "Test Location", "latitude": 28.0, "longitude": 77.0,
            "pm25": 45.0, "timestamp": ambiguous_date_str
        }]
        
        valid2, metrics2 = self.openaq.validate_and_filter(raw_records_2)
        self.assertEqual(len(valid2), 1)
        self.assertIn("T", valid2[0]["timestamp"]) # Should maintain ISO format strings

    def test_fuzzy_matching_logic(self):
        lookup_df = pd.DataFrame([{
            "station_id": "site_test",
            "station_name": "Delhi Technological University",
            "city": "Delhi",
            "clean_name": "delhi technological univ. - dpcc",
            "clean_key": "delhi technological univ. - dpcc_delhi"
        }])
        
        raw_records = [{
            "city": "Delhi", "station": "Delhi Technological Univ. - DPCC", "data_source": "openaq",
            "timestamp": "2026-09-11T10:00:00Z", "pm25": 40.0
        }]
        
        df = map_stations(raw_records, lookup_df)
        self.assertEqual(len(df), 1)
        self.assertEqual(df.iloc[0]["station_id"], "site_test")
        
    @patch('requests.get')
    def test_ozone_mapping_to_o3(self, mock_get):
        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            'records': [
                {'last_update': self.fresh_time, 'station': 'TestStation', 'city': 'Delhi', 'latitude': '28.0', 'longitude': '77.0', 'pollutant_id': 'OZONE', 'pollutant_avg': 45.0}
            ],
            'total': 1
        }
        mock_get.return_value = mock_resp
        
        # Process through CPCB source to see if OZONE becomes o3
        records = self.cpcb.fetch(['Delhi'])
        self.assertEqual(len(records), 1)
        self.assertIn("o3", records[0])
        self.assertEqual(records[0]["o3"], 45.0)
        
    def test_negative_values_clamped(self):
        # We clamp invalid negative data (calibration drift) to 0 rather than dropping
        now = datetime.datetime.now(datetime.timezone.utc)
        raw_records = [{
            "station": "Test Location", "latitude": 28.0, "longitude": 77.0,
            "pm25": -10.0, "timestamp": now.strftime('%Y-%m-%dT%H:%M:%SZ')
        }]
        valid, metrics = self.openaq.validate_and_filter(raw_records)
        self.assertEqual(len(valid), 1)
        self.assertEqual(valid[0]["pm25"], 0.0)
        
    @patch('fetchers.fetch_cpcb.logger.warning')
    def test_unmatched_station_logged_and_dropped(self, mock_warn):
        lookup_df = pd.DataFrame([{
            "station_id": "site_test",
            "station_name": "Valid Station",
            "city": "Delhi",
            "clean_name": "valid station",
            "clean_key": "valid station_delhi"
        }])
        
        raw_records = [{
            "city": "Delhi", "station": "Unknown Weird Station", "data_source": "cpcb",
            "timestamp": "2026-09-11T10:00:00Z", "pm25": 40.0
        }]
        
        df = map_stations(raw_records, lookup_df)
        self.assertEqual(len(df), 0)
        mock_warn.assert_called_once()
        self.assertIn("Dropping 1 rows. Unmatched stations:", mock_warn.call_args[0][0])

if __name__ == '__main__':
    unittest.main()
