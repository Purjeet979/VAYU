import urllib.request
import json
import traceback

def fetch_json(url):
    try:
        res = urllib.request.urlopen(url).read()
        return json.dumps(json.loads(res), indent=2)
    except Exception as e:
        return str(e)

print("Current Domain GRAP:")
print(fetch_json('http://localhost:8000/api/grap/current'))
print("\nDelhi GRAP:")
print(fetch_json('http://localhost:8000/api/grap/Delhi'))
print("\nGurugram GRAP:")
print(fetch_json('http://localhost:8000/api/grap/Gurugram'))
