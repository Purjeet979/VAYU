import json

path = r"C:\Users\PURJEET\.gemini\antigravity-ide\brain\4b0fcf87-83fa-4474-8c56-27c8e34ab9f8\.system_generated\logs\transcript.jsonl"
with open(path, "r", encoding="utf-8") as f:
    for line in f:
        try:
            data = json.loads(line)
            if "tool_calls" in data:
                for tc in data["tool_calls"]:
                    if tc["name"] in ["default_api:replace_file_content", "default_api:write_to_file", "default_api:multi_replace_file_content"]:
                        args = tc["arguments"]
                        if "main.py" in args.get("TargetFile", ""):
                            # Print the last 1500 chars to see if it has the cams function
                            if "TargetContent" in args:
                                if "def get_cams_comparison" in args["ReplacementContent"]:
                                    print("FOUND IN REPLACEMENT CONTENT:")
                                    print(args["ReplacementContent"])
                            if "CodeContent" in args:
                                if "def get_cams_comparison" in args["CodeContent"]:
                                    print("FOUND IN CODE CONTENT:")
                                    print(args["CodeContent"])
                            if "ReplacementChunks" in args:
                                for chunk in args["ReplacementChunks"]:
                                    if "def get_cams_comparison" in chunk["ReplacementContent"]:
                                        print("FOUND IN MULTI REPLACEMENT CONTENT:")
                                        print(chunk["ReplacementContent"])
        except Exception as e:
            pass
