"""
generate_nowcast_grid.py
=========================
VayuSangam — Live "Nowcast" grid generator.

PURPOSE
-------
Replaces the static forecast_demo.nc for the CURRENT-CONDITIONS map layer only.
This does NOT replace WRF-Chem or the 72-hour forecast — it produces a live,
recomputed spatial surface from real point observations (CPCB + OpenAQ) using
Inverse Distance Weighting (IDW).

This must be clearly labeled in the UI as "Live Conditions" (nowcast), never
as "72h Forecast". Mixing the two is a labeling/honesty bug, not a feature.

DESIGN — follows the same conventions used across the fetchers in this project:
  - Reads already-fetched live station data (CPCB + OpenAQ meta/output files),
    does not hit external APIs itself.
  - NaN values are preserved, never zero-filled.
  - Negative pollutant values are clamped to zero (calibration-drift defensive).
  - Atomic write (.tmp + os.replace) so partial writes never corrupt the file
    a running frontend/backend might be reading mid-write.
  - Writes a meta.json alongside the grid with last_fetch_utc, station_count,
    and interpolation_method, so the "Live" vs "Demo" badge has a single
    source of truth to check against (same idea as the data_confidence badge).
  - If station count is too low for a stable interpolation, the script FAILS
    LOUDLY (raises / returns a status flag) rather than silently producing a
    fabricated-looking surface — same principle as the counterfactual 501 and
    the CPCB fallback logging.

USAGE
-----
    python generate_nowcast_grid.py \
        --cpcb data/live/cpcb_live.csv \
        --openaq data/live/openaq_live.csv \
        --out data/live/nowcast_grid.json \
        --grid-bounds 76.5 28.0 78.5 29.3 \
        --resolution 0.05

Run this on a schedule (same cadence as your CPCB/OpenAQ fetch — hourly is
fine per the earlier OpenAQ polling-interval discussion) e.g. via cron or
inside your existing fetch orchestrator, right after the live fetchers run.
"""

import argparse
import json
import os
import sys
import tempfile
from datetime import datetime, timezone

import numpy as np
import pandas as pd

MIN_STATIONS_REQUIRED = 5  # below this, IDW is unstable / not honestly representable


def load_stations(cpcb_path: str, openaq_path: str) -> pd.DataFrame:
    """Load and merge live station observations.
    Parses the pivoted cpcb_live.csv and joins with cpcb_stations.csv for coordinates.
    """
    if not cpcb_path or not os.path.exists(cpcb_path):
        raise RuntimeError("Live station data not found at " + str(cpcb_path))
        
    df = pd.read_csv(cpcb_path)
    
    # Check if this is the pivoted format
    if 'pm25' in df.columns:
        # We need to get lat/lon from cpcb_stations.csv
        stations_path = os.path.join(os.path.dirname(os.path.dirname(cpcb_path)), "cpcb_stations.csv")
        if os.path.exists(stations_path):
            stations_df = pd.read_csv(stations_path)
            df = df.merge(stations_df[["station_id", "lat", "lon"]], on="station_id", how="left")
            
        import sys
        sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))
        from backend.app.aqi_calculator import calculate_overall_aqi
        def safe_aqi(row):
            pollutants = {
                "pm25": float(row.get('pm25')) if pd.notna(row.get('pm25')) else None,
                "pm10": float(row.get('pm10')) if pd.notna(row.get('pm10')) else None,
                "no2": float(row.get('no2')) if pd.notna(row.get('no2')) else None,
                "o3": float(row.get('o3')) if pd.notna(row.get('o3')) else None,
                "co": float(row.get('co')) if pd.notna(row.get('co')) else None,
                "so2": float(row.get('so2')) if pd.notna(row.get('so2')) else None,
            }
            aqi, _ = calculate_overall_aqi(pollutants)
            return aqi if aqi > 0 else np.nan
            
        df['aqi'] = df.apply(safe_aqi, axis=1)

        # Melt the dataframe
        value_vars = [col for col in ['pm25', 'pm10', 'no2', 'o3', 'co', 'so2', 'aqi'] if col in df.columns]
        merged = df.melt(id_vars=['station_id', 'lat', 'lon', 'timestamp'], value_vars=value_vars, 
                         var_name='pollutant', value_name='value')
        merged['source'] = 'CPCB/OpenAQ'
        merged.rename(columns={'timestamp': 'observed_at_utc'}, inplace=True)
    else:
        # Fallback to generic unpivoted format if provided
        merged = df
        if 'source' not in merged.columns:
            merged['source'] = 'Unknown'

    # Defensive clamp — never zero-fill NaN, only clamp genuine negative readings
    merged["value"] = merged["value"].apply(
        lambda v: max(v, 0) if pd.notna(v) else v
    )

    # Drop rows with no usable coordinates or value
    merged = merged.dropna(subset=["lat", "lon"])
    return merged


def idw_interpolate(
    stations: pd.DataFrame,
    pollutant: str,
    grid_lats: np.ndarray,
    grid_lons: np.ndarray,
    power: float = 2.0,
) -> np.ndarray:
    """
    Inverse Distance Weighting interpolation for one pollutant onto a
    lat/lon mesh grid. Returns a 2D array shaped (len(grid_lats), len(grid_lons)).
    Cells with no nearby valid station within a sane radius fall back to NaN
    (preserved downstream, never fabricated).
    """
    sub = stations[(stations["pollutant"] == pollutant) & stations["value"].notna()]
    if len(sub) < MIN_STATIONS_REQUIRED:
        print(
            f"[nowcast] Only {len(sub)} live '{pollutant}' stations available "
            f"(need {MIN_STATIONS_REQUIRED}+). Returning all-NaN grid for this pollutant "
            f"instead of an unstable/fabricated-looking surface.",
            file=sys.stderr,
        )
        return np.full((len(grid_lats), len(grid_lons)), np.nan)

    lats = sub["lat"].to_numpy()
    lons = sub["lon"].to_numpy()
    vals = sub["value"].to_numpy()

    grid = np.full((len(grid_lats), len(grid_lons)), np.nan)

    for i, glat in enumerate(grid_lats):
        for j, glon in enumerate(grid_lons):
            # squared distance in degrees is fine at this regional scale;
            # swap for haversine if you need metric accuracy near domain edges
            d2 = (lats - glat) ** 2 + (lons - glon) ** 2
            d2 = np.where(d2 == 0, 1e-12, d2)  # avoid div-by-zero if grid pt == station
            weights = 1.0 / (d2 ** (power / 2))
            grid[i, j] = np.sum(weights * vals) / np.sum(weights)

    return grid


def atomic_write_json(path: str, payload: dict) -> None:
    """Write JSON via temp file + os.replace so a concurrent reader never sees
    a half-written file — same pattern as the other live fetchers in this repo.
    """
    dir_name = os.path.dirname(os.path.abspath(path)) or "."
    fd, tmp_path = tempfile.mkstemp(dir=dir_name, suffix=".tmp")
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(payload, f, allow_nan=True, indent=2)
        os.replace(tmp_path, path)
    except Exception:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
        raise


def main():
    parser = argparse.ArgumentParser(description="Generate a live IDW nowcast grid.")
    parser.add_argument("--cpcb", required=False, default="data/live/cpcb_live.csv")
    parser.add_argument("--openaq", required=False, default="data/live/openaq_live.csv")
    parser.add_argument("--out", required=False, default="data/live/nowcast_grid.json")
    parser.add_argument(
        "--grid-bounds",
        nargs=4,
        type=float,
        metavar=("MIN_LON", "MIN_LAT", "MAX_LON", "MAX_LAT"),
        default=[76.5, 28.0, 78.5, 29.3],
        help="Bounding box for the nowcast grid. Should cover full NCR extent, "
             "not just the old demo domain — this is one of the things that "
             "was flagged as too small in forecast_demo.nc.",
    )
    parser.add_argument("--resolution", type=float, default=0.05, help="Grid spacing in degrees.")
    parser.add_argument(
        "--pollutants",
        nargs="+",
        default=["pm25", "pm10", "no2", "o3", "aqi"],
        help="Pollutant columns to interpolate. Must match values in the 'pollutant' column.",
    )
    args = parser.parse_args()

    min_lon, min_lat, max_lon, max_lat = args.grid_bounds
    grid_lats = np.arange(min_lat, max_lat + args.resolution, args.resolution)
    grid_lons = np.arange(min_lon, max_lon + args.resolution, args.resolution)

    try:
        stations = load_stations(args.cpcb, args.openaq)
    except RuntimeError as e:
        # Fail loudly — do not write a fabricated grid, do not silently pass
        print(f"[nowcast] FATAL: {e}", file=sys.stderr)
        sys.exit(1)

    layers = {}
    station_counts = {}
    for pollutant in args.pollutants:
        grid = idw_interpolate(stations, pollutant, grid_lats, grid_lons)
        layers[pollutant] = grid.tolist()  # NaN serializes as null via allow_nan
        station_counts[pollutant] = int(
            len(stations[(stations["pollutant"] == pollutant) & stations["value"].notna()])
        )

    now_utc = datetime.now(timezone.utc).isoformat()

    payload = {
        "type": "nowcast",  # NOT "forecast" — keep this distinction explicit in the schema
        "generated_at_utc": now_utc,
        "grid": {
            "lats": grid_lats.tolist(),
            "lons": grid_lons.tolist(),
        },
        "layers": layers,
        "interpolation_method": "idw",
        "idw_power": 2.0,
        "min_stations_required": MIN_STATIONS_REQUIRED,
        "station_counts_by_pollutant": station_counts,
        "total_stations_used": int(len(stations)),
        "sources": sorted(stations["source"].unique().tolist()),
    }

    atomic_write_json(args.out, payload)

    # Sidecar meta.json — single source of truth the frontend "Live" badge
    # should check, matching the pattern used by the other fetchers.
    meta_path = os.path.splitext(args.out)[0] + ".meta.json"
    meta = {
        "last_fetch_utc": now_utc,
        "row_count": int(len(stations)),
        "is_live": True,          # this file is only ever written from live inputs
        "layer_type": "nowcast",  # frontend should badge this "Live Conditions",
                                   # and keep "72h Forecast" on a separate, honestly
                                   # labeled Demo/Offline badge until WRF-Chem output
                                   # is wired in (Phase 5).
    }
    atomic_write_json(meta_path, meta)

    print(f"[nowcast] Wrote grid to {args.out} ({len(stations)} stations, "
          f"{len(args.pollutants)} pollutants) at {now_utc}")


if __name__ == "__main__":
    main()
