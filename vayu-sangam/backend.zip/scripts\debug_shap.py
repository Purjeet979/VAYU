import sys
sys.path.append('/home/ubuntu')
from backend.app.ml_explainer import explain_hour, _load_models, _current_weather_features
print('MODELS:', _load_models() is not None)
print('FEATURES:', _current_weather_features(24) is not None)
print('EXPLAIN:', explain_hour(24) is not None)
