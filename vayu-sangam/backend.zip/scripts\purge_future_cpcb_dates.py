import pandas as pd
from datetime import datetime, timezone
from pathlib import Path

def purge_future_dates():
    data_dir = Path('e:/SIH2/Vayusangam/vayu-sangam/backend/data')
    now = pd.Timestamp(datetime.now(timezone.utc))
    
    for filename in ['cache/cpcb_cache.csv', 'live/cpcb_live.csv']:
        file_path = data_dir / filename
        if not file_path.exists():
            print(f"Skipping {file_path}, does not exist.")
            continue
            
        df = pd.read_csv(file_path)
        parsed = pd.to_datetime(df['timestamp'], utc=True)
        
        future_mask = parsed > now
        if future_mask.any():
            print(f"Found {future_mask.sum()} future/corrupted rows in {filename}. Purging...")
            df_clean = df[~future_mask]
            df_clean.to_csv(file_path, index=False)
            print(f"Purged {filename}. Remaining rows: {len(df_clean)}")
        else:
            print(f"No future rows found in {filename}.")

if __name__ == "__main__":
    purge_future_dates()
