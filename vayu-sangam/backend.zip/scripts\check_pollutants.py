import json
from pathlib import Path
import os

live_dir = Path(__file__).resolve().parent.parent / "data" / "live"
cpcb_file = live_dir / "cpcb_live.json"

if not cpcb_file.exists():
    print(f"File not found: {cpcb_file}")
    exit(1)

with open(cpcb_file, 'r', encoding='utf-8') as f:
    data = json.load(f)

total_stations = len(data)
print(f"Total stations: {total_stations}")

pollutants = ["pm25", "pm10", "no2", "so2", "co", "o3"]
counts = {p: 0 for p in pollutants}

for station in data:
    for p in pollutants:
        # Some payloads might have the pollutant inside an 'aqi_details' object or directly.
        # Let's check both or directly in station dict
        val = station.get(p)
        if val is not None and str(val).lower() not in ['na', 'none', '']:
            counts[p] += 1

print("\nValid non-null values per pollutant in CPCB live data:")
for p in pollutants:
    pct = (counts[p] / total_stations) * 100 if total_stations > 0 else 0
    print(f"{p.upper():<5}: {counts[p]:>3} / {total_stations} ({pct:.1f}%)")
