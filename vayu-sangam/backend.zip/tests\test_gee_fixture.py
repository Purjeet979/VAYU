import pytest
import numpy as np
import pandas as pd
from unittest.mock import patch, MagicMock

# Import the parsing logic from fetch_aod and fetch_hcho
from backend.fetchers.fetch_aod import get_grid_points

def test_aod_parsing_logic():
    """Test that a mocked GEE feature collection response correctly maps to a 2D numpy grid."""
    
    # Mock lat/lon bounds
    lat_vals = np.linspace(27, 31, 24)
    lon_vals = np.linspace(73, 80, 26)
    
    # Create a mock GEE response
    mock_data = {
        'features': [
            {
                'properties': {
                    'lat': lat_vals[0],
                    'lon': lon_vals[0],
                    'first': 0.45  # Example AOD value
                }
            },
            {
                'properties': {
                    'lat': lat_vals[10],
                    'lon': lon_vals[10],
                    'first': 0.88
                }
            }
        ]
    }
    
    live_flat = np.full((len(lat_vals), len(lon_vals)), np.nan)
    
    for feat in mock_data.get('features', []):
        props = feat.get('properties', {})
        lat = props.get('lat')
        lon = props.get('lon')
        val = props.get('first')
        
        if val is not None and lat is not None and lon is not None:
            lat_idx = (np.abs(lat_vals - lat)).argmin()
            lon_idx = (np.abs(lon_vals - lon)).argmin()
            live_flat[lat_idx, lon_idx] = val
            
    # Verify mapping
    assert live_flat[0, 0] == 0.45
    assert live_flat[10, 10] == 0.88
    assert np.isnan(live_flat[1, 1])
    
    # Test spatial filling (ffill/bfill)
    df = pd.DataFrame(live_flat)
    df = df.ffill(axis=0).bfill(axis=0).ffill(axis=1).bfill(axis=1)
    filled_flat = df.values
    
    assert not np.isnan(filled_flat).any()
    assert filled_flat[1, 1] == 0.45  # ffill/bfill from nearest valid cell
