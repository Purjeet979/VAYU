import os
import json
import numpy as np
import pandas as pd
import logging
from pathlib import Path
from math import radians, cos, sin, asin, sqrt

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
CACHE_DIR = DATA_DIR / "cache"
LIVE_DIR = DATA_DIR / "live"
CPCB_CACHE_FILE = CACHE_DIR / "cpcb_cache.csv"
CAMS_FILE = LIVE_DIR / "cams_forecast.json"

def haversine(lat1, lon1, lat2, lon2):
    """Calculate the great circle distance in km between two points on the earth."""
    lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2])
    dlon = lon2 - lon1 
    dlat = lat2 - lat1 
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * asin(sqrt(a)) 
    r = 6371 # Radius of earth in kilometers.
    return c * r

def align_timezone_to_utc(df_cpcb, df_cams):
    """
    Methodological Foundation 1: Time-Zone Alignment
    CPCB typically reports in local time (IST). CAMS reports in UTC.
    We explicitly localize CPCB to IST (Asia/Kolkata) and convert to UTC for exact matching.
    """
    logger.info("Aligning timestamps to explicit UTC...")
    
    # Process CPCB
    df_cpcb = df_cpcb.copy()
    
    # Some older fetchers or sources might already be in UTC if data_source == openaq
    # For safety, we check if tz is aware. If not, assume IST for CPCB
    parsed_time = pd.to_datetime(df_cpcb['timestamp'], errors='coerce')
    
    if parsed_time.dt.tz is None:
        parsed_time = parsed_time.dt.tz_localize('Asia/Kolkata').dt.tz_convert('UTC')
    else:
        parsed_time = parsed_time.dt.tz_convert('UTC')
        
    df_cpcb['timestamp_utc'] = parsed_time
    # Round to nearest hour for matching
    df_cpcb['hour_utc'] = df_cpcb['timestamp_utc'].dt.floor('h')
    
    # Process CAMS
    df_cams = df_cams.copy()
    cams_time = pd.to_datetime(df_cams['forecast_time_utc'], errors='coerce')
    if cams_time.dt.tz is None:
        cams_time = cams_time.dt.tz_localize('UTC')
    else:
        cams_time = cams_time.dt.tz_convert('UTC')
        
    df_cams['hour_utc'] = cams_time.dt.floor('h')
    
    return df_cpcb, df_cams

def spatial_match_cams_to_cpcb(df_cpcb, df_cams):
    """
    Methodological Foundation 2: Spatial Matching
    Find the exact nearest CAMS gridpoint for each CPCB station using Haversine distance,
    instead of visual eyeballing.
    """
    logger.info("Performing Haversine nearest-neighbor spatial matching...")
    
    # Get unique CPCB stations and their lat/lon. 
    # Wait, cpcb_cache.csv doesn't always have lat/lon directly, we might need station_lookup
    station_lookup_path = DATA_DIR / "cpcb_stations.csv"
    if not station_lookup_path.exists():
        logger.error(f"Missing {station_lookup_path}")
        return df_cpcb
        
    stations = pd.read_csv(station_lookup_path)
    
    cams_points = df_cams[['lat', 'lon']].drop_duplicates().reset_index(drop=True)
    
    # Pre-compute nearest gridpoint for each station
    nearest_map = {}
    for _, st_row in stations.iterrows():
        st_id = st_row['station_id']
        st_lat = st_row['lat']
        st_lon = st_row['lon']
        
        if pd.isna(st_lat) or pd.isna(st_lon):
            continue
            
        distances = cams_points.apply(lambda r: haversine(st_lat, st_lon, r['lat'], r['lon']), axis=1)
        nearest_idx = distances.idxmin()
        nearest_map[st_id] = {
            'cams_lat': cams_points.loc[nearest_idx, 'lat'],
            'cams_lon': cams_points.loc[nearest_idx, 'lon'],
            'distance_km': distances.min()
        }
    
    # Map back to CPCB DataFrame
    df_cpcb['cams_lat'] = df_cpcb['station_id'].map(lambda x: nearest_map.get(x, {}).get('cams_lat'))
    df_cpcb['cams_lon'] = df_cpcb['station_id'].map(lambda x: nearest_map.get(x, {}).get('cams_lon'))
    
    return df_cpcb

def validate_and_normalize_co_unit(df_cpcb, df_cams):
    """
    Methodological Foundation 3: Unit Consistency for CO
    CPCB reports CO in mg/m3. CAMS was converted to ug/m3.
    We explicitly convert CAMS CO to mg/m3 for an apples-to-apples comparison.
    """
    logger.info("Normalizing CO units (CAMS ug/m3 -> mg/m3 to match CPCB)...")
    if 'co' in df_cams.columns:
        df_cams['co_mg_m3'] = df_cams['co'] / 1000.0
    return df_cams

def main():
    if not CPCB_CACHE_FILE.exists() or not CAMS_FILE.exists():
        logger.error("Required data files missing. Ensure CPCB and CAMS fetchers have run.")
        return
        
    df_cpcb = pd.read_csv(CPCB_CACHE_FILE)
    
    with open(CAMS_FILE, "r") as f:
        cams_data = json.load(f)
    df_cams = pd.DataFrame(cams_data)
    
    # Apply methodological foundations
    df_cpcb, df_cams = align_timezone_to_utc(df_cpcb, df_cams)
    df_cpcb = spatial_match_cams_to_cpcb(df_cpcb, df_cams)
    df_cams = validate_and_normalize_co_unit(df_cpcb, df_cams)
    
    df_cpcb = df_cpcb.dropna(subset=['cams_lat', 'cams_lon'])
    
    # Merge CPCB and CAMS on exact spatial and temporal alignment
    df_merged = pd.merge(
        df_cpcb, df_cams, 
        left_on=['cams_lat', 'cams_lon', 'hour_utc'], 
        right_on=['lat', 'lon', 'hour_utc'],
        suffixes=('_cpcb', '_cams')
    )
    
    if df_merged.empty:
        logger.warning("No overlapping spatial/temporal data points found between CPCB and CAMS.")
        
    # Check for historical depth
    min_date = df_cpcb['hour_utc'].min()
    max_date = df_cpcb['hour_utc'].max()
    history_days = (max_date - min_date).days if pd.notna(min_date) and pd.notna(max_date) else 0
    
    logger.info(f"Temporal span of CPCB data: {min_date} to {max_date} ({history_days} days)")
    
    if history_days < 14:
        logger.error(f"FLAG: Insufficient historical data — cannot yet quantify bias. Requires 2-4 weeks, found {history_days} days.")
        logger.info("Will NOT fabricate bias numbers. Proceeding to stop Phase 2 safely until data accumulates.")
        
        # Save a placeholder report acknowledging the lack of data
        report = {
            "status": "INSUFFICIENT_DATA",
            "history_days_available": history_days,
            "required_days": 14,
            "message": "Waiting for sufficient historical overlap to rigorously quantify CAMS bias."
        }
        with open(BASE_DIR / "scripts" / "cams_bias_report.json", "w") as f:
            json.dump(report, f, indent=2)
            
        return

    # If we had data, we would calculate RMSE and mean bias here
    logger.info("Sufficient historical data found. Calculating bias...")
    # Bias calculation logic would go here...

if __name__ == "__main__":
    main()
