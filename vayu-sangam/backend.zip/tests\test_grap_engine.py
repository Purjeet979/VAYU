import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
import pytest
from app.grap_engine import get_grap_stage

@pytest.mark.parametrize("aqi,expected_stage", [
    (200, "None"),     # Boundary: just below Stage I
    (201, "Stage I"),  # Boundary: start of Stage I
    (250, "Stage I"),  # Interior Stage I
    (300, "Stage I"),  # Boundary: end of Stage I
    (301, "Stage II"), # Boundary: start of Stage II
    (350, "Stage II"), # Interior Stage II
    (400, "Stage II"), # Boundary: end of Stage II
    (401, "Stage III"),# Boundary: start of Stage III
    (420, "Stage III"),# Interior Stage III
    (450, "Stage III"),# Boundary: end of Stage III (usually >450 is Stage IV)
    (451, "Stage IV"), # Boundary: start of Stage IV
    (480, "Stage IV"), # Interior Stage IV
])
def test_grap_stage_thresholds(aqi, expected_stage):
    res = get_grap_stage(aqi)
    assert res["stage"] == expected_stage
    if expected_stage != "None":
        assert "refer to official caqm order" in res["note"].lower()

