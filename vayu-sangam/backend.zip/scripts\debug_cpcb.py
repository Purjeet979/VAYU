import pandas as pd
df = pd.read_csv('e:/SIH2/Vayusangam/vayu-sangam/backend/data/cache/cpcb_cache.csv')
df['parsed'] = pd.to_datetime(df['timestamp'])
target = pd.to_datetime('2026-09-14 00:00:00')
df['diff'] = abs((df['parsed'] - target).dt.total_seconds())
closest = df.sort_values('diff').head(5)
print('Closest CPCB readings to 2026-09-14 00:00:00:')
for _, row in closest.iterrows():
    print(f"{row['station_name']} at {row['timestamp']}: PM2.5 = {row['pm25']}")
